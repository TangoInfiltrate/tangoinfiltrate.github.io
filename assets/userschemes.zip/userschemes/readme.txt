PATHS:
Linux: ~/.lazarus/userschemes
Windows: C:\users\USER\Local\AppData\lazarus\userschemes